function suma (a,b){
    console.log(`suma = ${a+b}`)
}

let a = 2
let b = 3

suma(a,b)