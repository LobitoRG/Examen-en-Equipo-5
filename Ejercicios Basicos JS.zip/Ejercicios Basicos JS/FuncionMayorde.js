function mayordeEdad (a) {
    if(a>=18){
        console.log("Es mayor de edad")
    }
    else {
        console.log("Es menor de edad")
    }
}

let a = 8

mayordeEdad(a)