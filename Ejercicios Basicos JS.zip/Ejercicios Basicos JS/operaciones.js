const a = 2
const b = 2

console.log(`suma = ${a+b}`)

console.log(`Resta = ${a-b}`)

console.log(`Multiplicacion = ${a*b}`)
console.log(`divicion = ${a/b}`)