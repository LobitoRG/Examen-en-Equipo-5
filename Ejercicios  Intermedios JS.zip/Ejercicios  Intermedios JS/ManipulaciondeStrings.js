function toUpperCase (texto) {
    console.log(texto.toUpperCase())
}

const texto = 'hola'

toUpperCase(texto)