let persona = new Object()
 persona.nombre="adolfo"
 persona.edad = "21"
 persona.ciudad= "tepic"

 console.log(persona)