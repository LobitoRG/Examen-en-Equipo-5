function imprimirInfo (){
    let persona = new Object()
    persona.nombre="adolfo"
    persona.edad = "21"
    persona.ciudad= "tepic"
    console.log("soy "+persona.nombre+" Tengo "+persona.edad+" años y vivo en "+persona.ciudad)
}

imprimirInfo()